<?php 

@session_start();
include_once(dirname(__FILE__).'/_dbconfig.php');
mysqli_select_db($connect,$_SESSION['db']);

mysqli_query($connect, "SET lc_messages = 'fr_FR'");
// affiche le résultat en sur-impression
//echo "<script type=\"text/javascript\">$('#greybox').show();$('html').css('overflow', 'hidden');</script>";
				
					//var_dump($_POST);
					$motif='/^select\s/'; // chaine à rechercher : commence par select
//////////////////////$chaineminuscule=strtolower($_POST['sql']);
					$chaineminuscule=$message=str_replace("sql=","",strtolower(@$_POST['sql']));
					$resp="";
					if(!preg_match($motif, $chaineminuscule)) {// si ce n'est pas une requête de type select
						
						
						

						$resp='<table id="tabresult" cellspacing="0" cellpadding="5">';
						
						
							
							if(!$r=mysqli_query($connect, stripslashes($message))){
								$reponse= ("MySQL dit:<br><span class=\"alert alert-danger\"><span class=\"mysqlquote\">".utf8_encode(mysqli_error($connect))."</span></span><br>... C'est grave, tu crois ?");
							} else {
									$reponse=utf8_encode(mysqli_info($connect));
							}
						
							
							if($reponse!='') {
								// echo $reponse;
								$resp.=$reponse;
							} else {
								
								while($t=@mysqli_fetch_row($r)){
									$reponses[]=$t;
								}
								
							
								if(isset($reponses) && is_array($reponses)){
										foreach ($reponses as $key => $value) {
										// echo '<tr>';
											$resp.='<tr>';
											foreach ($value as $cle => $valeur) {
												// echo '<td>'.$valeur.'</td>';
												$resp.='<td>'.$valeur.'</td>';
											}
											// echo '</tr>';
											$resp.='</tr>';
										}
									
								} else {
										// echo "La requête n'a renvoyé aucun message d'erreur...<br>A priori c'est bon !" ;
										$resp.="La requête n'a renvoyé aucun message d'erreur...<br>A priori c'est bon !" ;
								}
								
							

							}
								
							$resp.="</table>";
													
					} else { // si c'est un select on affiche le tableau des résultats

					if(!$mysql_result=mysqli_query($connect, stripslashes($message)) ) {
						// echo ("MySQL dit:<br><span class=\"alert alert-danger\"><span class=\"mysqlquote\">".utf8_encode(mysqli_error($connect))."</span ></span><br>C'est grave, tu crois ?");
						$resp.="MySQL dit:<br><span class=\"alert alert-danger\"><span class=\"mysqlquote\">".utf8_encode(mysqli_error($connect))."</span ></span><br>C'est grave, tu crois ?";
					} else {


					//$ligne = mysqli_fetch_field($mysql_result);


					$tab=mysqli_fetch_array($mysql_result,MYSQLI_ASSOC);
					
					if(is_array($tab)){
						$numcol=count(array_keys($tab)); // car le 0 contient rien
			    		$res=array_keys($tab);
					} else {
						$numcol=null;
					}
				
					
					//<!-- AFFICHAGE DES RESULTATS -->
				$resp.='<span id="fontminus" class="btn btn-warning btn-xs" title="Dimunuer la police">-</span> 
				<span title="Augmenter la police" id="fontplus" class="btn btn-primary btn-xs">+</span>
					<table id="tabresult" cellspacing="0" cellpadding="5">';
					
					
						
						if($numcol>=1){
							$resp.= '	<tr class="ligneentete">';
							foreach ($res as $val) {
								$resp.= "<th>".$val."</th>";
							}

							$resp.= '</tr>';
						?>
						
						<?php
						}	
							// résultat vide ?
						if($numcol<0 || $numcol==''){
							$resp.= '<tr>
								<td><div class="text-center lead">La requête a retourné un résultat vide</div></td>
							</tr>';
						}
						$ligne=0;
						$mysql_result=mysqli_query($connect, stripslashes($message)) or die ("MySQL dit:<br><span class=\"alert alert-danger\"><span class=\"mysqlquote\">".utf8_encode(mysqli_error($connect))."</span></span>");
						while ($tab2=mysqli_fetch_array($mysql_result)){
							
							$resp.= '<tr>';
							for ($i=0;$i<$numcol;$i++){
								$resp.= "<td class=\"tabresult\"\">".htmlentities($tab2[$i])."</td>";
							}
							$resp.= '</tr>';
							$ligne++;
						}
						$resp.= "</table>";

						
						}
					} // fin si c'est un select

echo $resp;
 ?>